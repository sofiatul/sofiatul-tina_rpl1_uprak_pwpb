<?php
//include file config.php
include('config.php');
 
//jika benar mendapatkan GET id dari URL
if(isset($_GET['id_barang'])){
	//membuat variabel $id yang menyimpan nilai dari $_GET['id_barang']
	$id_barang = $_GET['id_barang'];
	
	//melakukan query ke database, dengan cara SELECT data yang memiliki id_barang yang sama dengan variabel $id_barang
	$cek = mysqli_query($koneksi, "SELECT * FROM barang WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
	
	//jika query menghasilkan nilai > 0 maka eksekusi script di bawah
	if(mysqli_num_rows($cek) > 0){
		//query ke database DELETE untuk menghapus data dengan kondisi id_barang=$id_barang
		$del = mysqli_query($koneksi, "DELETE FROM barang WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
		if($del){
			echo '<script>alert("Berhasil menghapus barang."); document.location="index.php";</script>';
		}else{
			echo '<script>alert("Gagal menghapus barang."); document.location="index.php";</script>';
		}
	}else{
		echo '<script>alert("ID_BARANG tidak ditemukan di database."); document.location="index.php";</script>';
	}
}else{
	echo '<script>alert("ID_BARANG tidak ditemukan di database."); document.location="index.php";</script>';
}
?>