<?php include('config.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>PENGINPUTAN IVENTORI BARANG</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">	
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container">
			<a class="navbar-brand" href="#">CRDU PHP MySQLi</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
 
			<div class="collapse navbar-collapse" id_barang="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="tambah.php">Tambah</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	
	<div class="container" style="margin-top:20px">
		<h2>Edit iventor</h2>
		
		<hr>
		
		<?php
		//jika sudah mendapatkan parameter GET id_barang dari URL
		if(isset($_GET['id_barang'])){
			//membuat variabel $id untuk menyimpan id_barang dari GET id_barang di URL
			$id_barang = $_GET['id_barang'];
			
			//query ke database SELECT tabel mahasiswa berdasarkan id_barang = $id_barang
			$select = mysqli_query($koneksi, "SELECT * FROM data WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
			
			//jika hasil query = 0 maka muncul pesan error
			if(mysqli_num_rows($select) == 0){
				echo '<div class="alert alert-warning">ID tidak ada dalam database.</div>';
				exit();
			//jika hasil query > 0
			}else{
				//membuat variabel $data dan menyimpan data row dari query
				$data = mysqli_fetch_assoc($select);
			}
		}
		?>
		
		<?php
		//jika tombol simpan di tekan/klik
		if(isset($_POST['submit'])){
			$no				= $_POST['no'];
			$id_barang		= $_POST['id_barang'];
			$nama_barang	= $_POST['nama_barang'];
			$keterangan		= $_POST['keterangan'];
			$jenis_barang	= $_POST['jenis_barang'];
			$jumlah_barang	= $_POST['jumlah_barang'];
			
			$sql = mysqli_query($koneksi, "UPDATE data SET no='$no', id_barang='$id_barang', nama_barang='$nama_barang', keterangan='$keterangan', jenis_barang='$jenis_barang', jumlah_barang='$jumlah_barang' WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
			
			if($sql){
				echo '<script>alert("Berhasil menyimpan data."); document.location="edit.php?id_barang='.$id_barang.'";</script>';
			}else{
				echo '<div class="alert alert-warning">Gagal melakukan proses edit data.</div>';
			}
		}
		?>
		
		<form action="edit.php?id_barang=<?php echo $id_barang; ?>" method="post">
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">no</label>
				<div class="col-sm-10">
					<input type="text" name="no" class="form-control" size="4" value="<?php echo $data['no']; ?>" readonly required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">ID_BARANG</label>
				<div class="col-sm-10">
					<input type="text" name="id_barang" class="form-control" value="<?php echo $data['id_barang']; ?>" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">NAMA_BARANG</label>
				<div class="col-sm-10">
					<input type="text" name="nama_barang" class="form-control" value="<?php echo $data['nama_barang']; ?>" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">KETERANGAN</label>
				<div class="col-sm-10">
					<input type="text" name="keterangan" class="form-control" value="<?php echo $data['keterangan']; ?>" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">JENIS_BARANG</label>
				<div class="col-sm-10">
					<select name="jurusan" class="form-control" required>
						<option value="">PILIH BARANG</option>
						<option value="KOMPUTER" <?php if($data['jenis_barang'] == 'KOMPUTER'){ echo 'selected'; } ?>>KOMPUTER</option>
						<option value="MOUSE" <?php if($data['jenis_barang'] == 'MOUSE'){ echo 'selected'; } ?>>MOUSE</option>
						<option value="CPU" <?php if($data['jenis_barang'] == 'CPU'){ echo 'selected'; } ?>>CPU</option>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">JUMLAH_BARANG</label>
				<div class="col-sm-10">
					<select name="fakultas" class="form-control" required>
						<option value="">JUMLAH_BARANG</option>
						<option value="1-5" <?php if($data['jumlah_barang'] == '1-5'){ echo 'selected'; } ?>>JUMLAH_BARANG</option>
						<option value="6-10" <?php if($data['jumlah_barang'] == '6-10'){ echo 'selected'; } ?>>JUMLAH_BARANG</option>
						<option value="11-20" <?php if($data['jumlah_barang'] == '11-20'){ echo 'selected'; } ?>>JUMLAH_BARANG</option>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">&nbsp;</label>
				<div class="col-sm-10">
					<input type="submit" name="submit" class="btn btn-primary" value="SIMPAN">
					<a href="index.php" class="btn btn-warning">KEMBALI</a>
				</div>
			</div>
		</form>
		
	</div>
	
	<script src="bootstrap/js/jquery.min.js"></script>
	<script src="bootstrap/popper.min.js"></script>
	<script src="/bootstrap/js/bootstrap.min.js"></script>
	
</body>
</html>