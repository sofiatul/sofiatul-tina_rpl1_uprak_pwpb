<?php include('config.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>CRUD dengan Bootstrap</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container">
			<a class="navbar-brand" href="#">CRUD PHP Tambah</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
 
			<div class="collapse navbar-collapse" id_barang="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="tambah.php">Tambah</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	
	<div class="container" style="margin-top:20px">
		<h2>Tambah barang</h2>
		
		<hr>
		
		<?php
		if(isset($_POST['submit'])){
			$id_barang			= $_POST['id_barang'];
			$nama_barang		= $_POST['nama_barang'];
			$keterangan			= $_POST['keterangan'];
			$jenis_barang		= $_POST['jenis_barang'];
			$jumlah_barang		= $_POST['jumlah_barang'];
			
			$cek = mysqli_query($koneksi, "SELECT * FROM barang WHERE id_barang='$id_barang'") or die(mysqli_error($koneksi));
			
			if(mysqli_num_rows($cek) == 0){
				$sql = mysqli_query($koneksi, "INSERT INTO barang(id_barang, nama_barang, keterangan, jenis_barang, jumlah_barang) VALUES('$id_barang', '$nama_barang', '$keterangan', '$jenis_barang', '$jumlah_barang')") or die(mysqli_error($koneksi));
				
				if($sql){
					echo '<script>alert("Berhasil menambahkan barang."); document.location="tambah.php";</script>';
				}else{
					echo '<div class="alert alert-warning">Gagal melakukan proses tambah barang.</div>';
				}
			}else{
				echo '<div class="alert alert-warning">Gagal, id_barang sudah terdaftar.</div>';
			}
		}
		?>
		
		<form action="tambah.php" method="post">
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">ID_BARANG</label>
				<div class="col-sm-10">
					<input type="text" name="id_barang" class="form-control" size="4" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">NAMA_BARANG</label>
				<div class="col-sm-10">
					<input type="text" name="nama_barang" class="form-control" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">KETERANGAN</label>
				<div class="col-sm-10">
					<input type="text" name="keterangan" class="form-control" required>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">JENIS_BARANG</label>
				<div class="col-sm-10">
					<select name="jenis_barang" class="form-control" required>
						<option value="">PILIH BARANG</option>
						<option value="KOMPUTER">KOMPUTER</option>
						<option value="MOUSE">MOUSEL</option>
						<option value="CPU">CPU</option>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">JUMLAH_BARANG</label>
				<div class="col-sm-10">
					<select name="jumlah_barang" class="form-control" required>
						<option value="">JUMLAH BARANG</option>
						<option value="1-5">1-5</option>
						<option value="6-10">6-10</option>
						<option value="11-20">11-20</option>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 col-form-label">&nbsp;</label>
				<div class="col-sm-10">
					<input type="submit" name="submit" class="btn btn-primary" value="SIMPAN">
				</div>
			</div>
		</form>
		
	</div>
	
	<script src="bootstrap/js/jquery.min.js"></script>
	<script src="bootstrap/popper.min.js"></script>
	<script src="/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>