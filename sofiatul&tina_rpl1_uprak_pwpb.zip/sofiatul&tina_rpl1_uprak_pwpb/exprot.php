<?php 
//disini kita akan mengkoneksikan database
$db_host='localhost'; //nama host
$db_user='root'; //nama user
$db_pass=''; //password
$db_db='iventori'; //database yang akan di hubungkan

$db_conn=mysql_connect($db_host,$db_user,$db_pass,$db_db) or die ('Tidak terhubung ke mysql');
$db_select=mysql_select_db($db_db) or die('Tidak terhubung ke database');
//kita akan menambahkan script export di sini
header("content-type:application/vnd-ms-exel");
//membuat file excel
header("content-disposition:attachment;filename=Data.xls");
//membuat nama file

?>

<table border="1" width="100%">
	<tr align="center" bgcolor="yellow">
		<td>ID_BARANG</td>
		<td>NAMA_BARANG</td>
		<td>KETERANGAN</td>
		<td>JENIS_BARANG</td>
		<td>JUMLAH_BARANG</td>
	</tr>
	<?php
		$query=mysql_query("select * from barang");
		while($barang=mysql_fetch_array($query))
		{
	 ?>
	<tr>

		<td><?php echo $barang['id_barang']; ?></td>
		<td><?php echo $barang['nama_barang']; ?></td>
		<td><?php echo $barang['keterangan']; ?></td>
		<td><?php echo $barang['jenis_barang']; ?></td>
		<td><?php echo $barang['jumlah_barang']; ?></td>
	</tr>
	<?php } ?>
</table>